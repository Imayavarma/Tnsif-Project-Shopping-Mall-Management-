package com.example.Customer;
import java.util.List;
import com.example.Customer.Customer;
public interface CustomerService {
	List<Customer> getAllCustomers();
    Customer getCustomerById(int id);
    Customer addCustomer(Customer customer);
    Customer updateCustomer(int id, Customer customer);
    void deleteCustomer(int id);
}
